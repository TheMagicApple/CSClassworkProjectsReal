import java.io.Serializable;

public class Game implements Serializable {
	public int[][] grid=new int[][] {{0,0,0},{0,0,0},{0,0,0}};
}
